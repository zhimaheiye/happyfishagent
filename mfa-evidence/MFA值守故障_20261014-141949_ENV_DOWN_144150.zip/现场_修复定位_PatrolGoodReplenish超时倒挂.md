# 修复定位 — 2026-10-14 14:00:41 队列死（台账 patrol_gate_abort 累计第 16 次）

## 一句话

巡检在**食物条已经 100/100 的乖海星**身上又点了一次「补充」，游戏不弹「选择喂食」窗；
`PatrolGoodReplenish` 的 3500 ms 预算先耗尽 ⇒ `on_error=PatrolAbortNavigation` ⇒ `FailTaskAction`
⇒ `任务失败：多鱼缸巡检` ⇒ 整条队列停在海星宠物页，到本包生成时（14:20）已停摆 19 分钟。

## 事实链（三条独立来源，全部可复核）

| 时刻 | 来源 | 内容 |
|---|---|---|
| 13:57:39.170 | GUI 日志 | `[海星喂食] 识别到深海鱼食` ⇒ 乖海星刚被投过食 |
| 14:00:35.313 | GUI 日志 | `[巡检-乖海星] 已点击补充鱼食，正在打开选择鱼食弹窗并识别可用类型。`（= `PatrolGoodReplenish` 的 `Node.Action.Succeeded`） |
| 14:00:40.213 / 14:00:41.208 | maafw 日志 | `PatrolGoodFoodRouter` OCR 两次只读到 `{"box":[655,99,118,50],"score":0.999967,"text":"亮海星"}`，`best=null` ⇒ `Node.Recognition.Failed`。**「选择喂食」四个字在屏上根本不存在** |
| 14:00:41.210 | maafw 日志 | `WRN PipelineTask.cpp L155 Task timeout [pretask.name=PatrolGoodReplenish] [duration_since(start_clock)=4294ms] [pretask.reco_timeout=3500ms]` |
| 14:00:41.236 | maafw 日志 | `save on error to .../2026.10.14-14.00.41.213_PatrolGoodReplenish.png` |
| 14:00:41.238 | maafw 日志 | `recognize_list [cur_node_=PatrolGoodReplenish] [list=[{"name":"PatrolAbortNavigation"}]]` ⇒ 走的是**父节点**的 on_error |
| 14:00:41.453 | GUI 日志 | `[巡检] ERROR：页面门禁未通过，已停止且未继续点击。` |
| 14:00:41.825 | GUI 日志 | `任务运行失败！`（此后全天再无业务行） |

两张 on_error 帧（`.213_PatrolGoodReplenish` / `.658_PatrolAbortNavigation`）md5 相同：`be8c0512f29044d55c4db1e989b70fc1`，
画面 = 乖海星页签 + 食物条 `100/100` + 「预计可喂食：1天」+ **无遮罩弹窗**。
值守 14:34:27 的只读截图（`现场_只读截图_143427_仍停在乖海星页.png`）与它同一页 ⇒ 停摆后 34 分钟画面没变过，也没有人接手。

## 配置定位

文件：`D:\MaaHappyFish-win-x86_64-v0.4.4\resource\pipeline\features\patrol.json`（本包 `配置只读副本/` 内有同一份）

```
PatrolGoodReplenish   expected「补充」  roi[880,250,300,120]  Click  post_delay 1600  timeout 3500
                      on_error [PatrolAbortNavigation]        next   [PatrolGoodFoodRouter]
PatrolGoodFoodRouter  expected「选择喂食」 roi[560,70,420,160]  DoNothing  timeout 4000
                      on_error [PatrolGoodFoodMissed]         next   [PatrolGoodPickFood]
```

**超时倒挂（确定的配置缺陷）**：`3500 < post_delay 1600 + 4000`。父节点预算必然先耗尽，
所以 `PatrolGoodFoodMissed`（会打印「廉价、普通、高级和深海鱼食都未识别，已停止，未点击其它鱼食」）
在这条路上**永远走不到**，真实原因被改写成一句笼统的「页面门禁未通过」，白耗定位时间。
⚠️ 两条路最后都调 `FailTaskAction`，所以这个倒挂只影响**诊断文案**，不影响队列存活——别把它当成停摆的原因。

## 缺的判据（**推断**，需芝麻确认游戏行为后再动手）

满条时点「补充」到底弹不弹窗，我没有反例可查（今天 284 次点击只有这 1 次没等到弹窗）。
最可能的解释：**食物条已满 ⇒ 游戏不开选择窗**，而巡检没有「已满就跳过这只海星」的分支——
三只海星每 30 秒无条件各点一次，只要有一只先被喂满，下一轮就死。

## 候选改法（只列，不改；改 pipeline 归芝麻）

1. 点「补充」之前先读食物条文本（`100/100` 一类，roi 需按实机标定），命中即跳过该海星、直接切下一只页签。
2. 把 `Patrol*Replenish.timeout` 抬到 ≥ `post_delay + Patrol*FoodRouter.timeout + 余量`（或把子节点 timeout 压到父预算内），
   让 `Patrol*FoodMissed` 真能被走到，报错文案回到具体原因。
3. 三只海星链上的 `on_error` 目前一律 `PatrolAbortNavigation`（= 打死整条队列）。可考虑改成「退回海星面板、继续下一只」，
   别让单只海星的喂食失败带走收宝与巡检。

## 值守侧结论

- 分类：**游戏卡页面/门禁类**，不是模拟器崩（`state=start_finished`）、不是整机崩（adb/游戏 pid 59344 在线、MFA 窗口在）、
  不是 Agent 静默挂死（失败三件套齐全：`任务失败：X` + `停止前状态：FAILED` + `任务运行失败！`）。
- 本包按日间档（08:00–21:59）**只记录不重启**：没有点过任何按钮、没有拉起、没有改任何配置。
- 恢复要两步：先点左上「返回」离开海星宠物页（⛔ 主鱼缸禁按 BACK），再确认队列里只有「多鱼缸巡检」后点「开始任务」。
