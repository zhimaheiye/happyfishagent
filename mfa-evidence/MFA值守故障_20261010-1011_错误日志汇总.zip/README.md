# MFA 值守故障 · 2026-10-10 ~ 10-11 错误日志汇总（仅近两天）

主题：接续 10-07 全日汇总包（此前 10-08 / 10-09 的故障已修复、证据包已按惯例清理），本包**只覆盖 2026-10-10 00:00 → 10-11 11:12** 的运行窗口。

总体结论：两天 24 个 maafw 会话 ERR/FTL **0 条真实错误**（147,881 条全部为 `get_reco_result` 轮询噪音）；实质问题集中在**主程序日志的任务级失败**与少量环境类 WRN，且均为已知形态的复现，无新故障类型。

## 一、maafw 会话总览（明细见 `maafw_err/summary.csv`）

bak 文件命名时间 = 会话被轮转（下一会话启动）的时刻，即该会话结束时刻。24 个会话「真实错误」列全为 0，故未生成任何 `*.err.log`。

- 「真实错误」= ERR/FTL 行中**剔除** `MaaTaskerGetRecognitionDetail failed to get_reco_result` 后的全部行（10-10 ~ 10-11 窗口内过滤）。
- 「轮询噪音」= `MaaTasker.cpp L359 MaaTaskerGetRecognitionDetail failed to get_reco_result`：MaaFramework 每次识别事件后 UI 查询识别详情未就绪时的 benign ERR，两天累计 **147,881 条**。每个会话保留前 30 条样本（`*.noise_sample.txt`）供确认。
- 值得留意的会话间隔（无 maafw 日志覆盖的空档）：
  - **10-10 08:03:53 → 10:41:27**（约 2.5 小时）：与主程序 08:03「获取图像失败」及 10:41 重启窗口吻合，见下节第 1、3 条。
  - 10-11 02:33:34 → 02:39:47：夜班中断后手动重启，与 02:12 / 02:49 两次巡检失败相邻。

## 二、主程序日志错误明细（`logs/`）

### 10-10（log-20261010.log）

1. **08:03:54 「获取图像失败：External component has thrown an exception」**（WRN ×1）—— 与该时段 maafw 会话尾段截屏异常一致，随后 08:04 前后会话轮转、值守出现 2.5 小时空档。
2. **10:41:39 与 12:04:22 GitHub 403 rate limit（ERR ×2 窗口）** —— 资源包版本检查失败：`请求 GitHub 失败：状态码=403 Forbidden，原因=rate limit exceeded`，本地版本 v0.7.8。伴随「跨平台数据解密失败：参数错误 / Base-64」WRN（会话启动伴生，已知形态）。不影响值守运行，仅升级检查不可用。
3. **11:00:34 与 16:35:13 海獭摸宝 ERROR ×2** —— `到达好友边界（LAST_FRIEND_STAMINA_UNVERIFIED)，未确认寻宝体力耗尽；本轮未完成，不增加今日次数`。安全停机，非崩溃；on_error 有 `SeaOtterLastFriendExhausted` ×3、`SeaOtterNavigationFailed` ×4、`SeaOtterRecommendedBridge` ×2、`SeaOtterHomeReturnWait` ×2 现场帧。
4. **11:15:34 购买鱼食**：`廉价鱼食第 1 轮购买失败`（后续轮次成功，任务未中断）。
5. **Focus 内容文件解析失败 WRN（多处）** —— `input` 与 `candidate` 仅 `/` vs `\` 差异导致 `exists=False`，已知解析噪音，不代表故障。

### 10-11（log-20261011.log，截至 11:12）

1. **02:12:48 与 02:49:10 多鱼缸巡检 ERROR ×2** —— `页面门禁未通过，已停止且未继续点击` → 任务失败。on_error 有 `PatrolAbortNavigation`（02:12、02:49）与 `PatrolSelectTank1/2FromPicker`（02:12、02:49）现场帧，疑似夜班该时段模拟器画面/页面状态异常，02:39 手动重启后仍复现一次，白天档未再出现。
2. **02:39 / 02:47 会话启动伴生 WRN** —— 跨平台数据解密失败、实时画面为空（模拟器窗口最小化/设备未完全启动）、公告文件夹不存在，均为重启时序伴生，无实际影响。

## 三、on_error 现场截图（174 张 → 采样 30 张 + 完整清单）

10-10 ~ 10-11 `debug/on_error/` 共 174 张，完整清单（文件名 / 日期 / 小时 / 场景 / 是否入包）见 `on_error_list/完整清单.csv`。

| 场景 | 张数 | 入包策略 |
|---|---|---|
| PatrolCollectTank1/2/3ImageWindow（巡检复查残留产物识别窗，51/50/50） | 151 | 已知高频良性场景（每轮巡检三缸各 1 张），按每缸每天保留首末样本，共 14 张 |
| PatrolSweepTank1AfterBubble（气泡后扫底） | 9 | 保留首末 2 张 |
| SeaOtterLastFriendExhausted（海獭好友边界停机） | 2 | 全部保留（11:00、16:35 两次 ERROR 现场） |
| SeaOtterNavigationFailed / SeaOtterHomeReturnWait（海獭导航失败/返回等待） | 各 1 | 全部保留 |
| PatrolAbortNavigation（巡检导航中止，10-11 夜班 02:12 / 02:49） | 2 | 全部保留 |
| 其余单发场景（RomanticHouseNextCouple / BuyFishFoodPurchaseOnDetail / ManateeFeedUntilExhausted / FriendGemExhausted / FriendGemDone / PatrolStartAtTank3 / PatrolSelectTank1/2FromPicker） | 各 1 | 全部保留 |

## 四、目录结构

```
logs/            主程序日志（log-20261010 / log-20261011，原样）
maafw_err/       summary.csv（24 会话统计总表）+ 各会话噪音样本（*.noise_sample.txt）
                 本期真实错误为 0，故无 *.err.log
on_error/        错误现场截图（30 张采样）
on_error_list/   完整清单.csv（174 条）
```
