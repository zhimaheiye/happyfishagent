# 修复定位：MuMuManager.exe 起不来 ⇒ 值守被误判 ENV_DOWN（2026-10-14 21:53 档）

## 一句话

`D:\MuMuPlayer\nx_main\MuMuManager.exe` 现在**任何子命令都以 0xc0000142（STATUS_DLL_INIT_FAILED）退出、stdout/stderr 全空**，而 `tools/mumu_dev.py` 把「进程起不来」和「实例不存在」压成同一个空 dict ⇒ `tools/mfa_guard.py:528` 报「MuMuManager 查不到实例 1 的信息」⇒ `mfa_night_watch.py` 21:53:31 判 **ENV_DOWN**。
**模拟器、adb、游戏、MFA 四个都是活的**（下面有实测），所以这是一次**由工具自身崩溃造成的假环境故障**；真正需要处理的是两件事：① MuMuManager 为什么起不来；② 游戏从 14:00:41 起一直停在**海星页 +「选择喂食」弹窗未关**（本包内附截图）。

## 事实链（全部 21:25–21:53 实测，只读动作）

| 项 | 实测结果 | 取法 |
|---|---|---|
| `MuMuManager.exe list` | rc **0xc0000142**，stdout/stderr 空 | subprocess 直调 |
| `MuMuManager.exe info -all` | rc **0xc0000142**，输出空 | 同上 |
| `MuMuManager.exe info -v 1`（cwd=nx_main） | rc **0xc0000142** | 换工作目录复测 |
| `cmd /c "MuMuManager.exe list"` | rc **0xc0000142** | 换启动路径复测，排除我这边 spawn 方式 |
| MuMu 进程族 | `MuMuNxMain.exe`×1、`MuMuNxService.exe`×1、`MuMuNxDevice.exe`×2、`MuMuNxSVC.exe`×1、`MuMuRemoteService/Backend/Healthd` 各 1 ⇒ **模拟器在跑** | `tasklist /fo csv` |
| adb 实例 1 | `adb -s 127.0.0.1:16416 shell echo ALIVE` → rc=0，输出 `ALIVE` ⇒ **通道通** | `D:\MuMuPlayer\nx_main\adb.exe` |
| 游戏进程 | `pidof com.happyelements.happyfishandroidcns` → **59344** | adb shell |
| 前台 Activity | `topResumedActivity` / `mCurrentFocus` = `com.happyelements.happyfishandroidcns/com.happyelements.happyfish.MainActivity` | adb dumpsys |
| MFA 进程 | `MaaHappyFish.exe` **PID 10660**，124,768 K | tasklist |
| MFA 框架日志 | `debug\maafw.log` 106,799,581 B，mtime **21:40:21** 仍在写；尾部 2,722 行 **[ERR] 0 条**；20:15–21:40 共 149,871 行**全部**来自 `MuMuPlayerExtras.cpp`（`get_display_id`，每 5 分钟稳定 8,8xx 行，窗内窗外无尖峰）⇒ 该时段**没有任何识别/流水线活动** | 按时间戳锚定统计 |
| Windows 事件 | `Application` 日志里 **0 条** MuMuManager 崩溃事件、0 条含 `c0000142`；`%LOCALAPPDATA%\CrashDumps` 无 MuMuManager 转储（最近的是 21:20:25 `SystemSettingsBroker.exe`）⇒ **WER 没记，属于进程初始化阶段就失败** | wevtutil + 目录列举 |
| 整机 | `System` 日志 Id 41/6008 今日 **0 条**（最近一对 2026-10-10T11:35Z）⇒ 不是整机崩 | 15:4x 档实测沿用（本会话未中断，机器没重启过） |
| 今天 GUI 日志里的 MuMuManager | **0 行**（`[摇一摇] 警告：MuMuManager ...` 全天 0 条）；最后一次 shake 成功 **10:03:38**（`本鱼缸 SHAKE 收宝结束（shake 成功 5/5 次` ⇒ 崩溃时刻在 **10:04 之后某处**，具体未验证 | 全天扫描 |

## 代码定位（值守侧，只读 grep/Read，未改任何文件）

- `tools/mumu_dev.py:35` `MGR = r"D:\MuMuPlayer\nx_main\MuMuManager.exe"`（硬编码单一路径，无第二候选）
- `tools/mumu_dev.py:40-45` `_run()`：`try: r=subprocess.run(...); return r.stdout.decode(...)  except Exception: return ""`
  ⇒ **退出码被完全丢弃**。0xc0000142 与「实例不存在」与「超时」在这里都变成 `""`。
- `tools/mumu_dev.py:48-54` `vm_info()`：`json.loads(_run([MGR,"info","-v","all"],45))` → 解析空串抛异常 → `except: return {}`
  ⇒ 静默降级成空 dict，**没有任何一条日志说明是工具崩了**。
- `tools/mfa_guard.py:146-148` `vm_info()` 只是转调上面那个。
- `tools/mfa_guard.py:525` `dev = vm_serial(info) if info else ("127.0.0.1:%d" % (PORT_BASE+32*int(VM_INDEX)))`
  ⇒ 端口有兜底（所以 adb 侧仍判通），但 `info` 为空这件事被单独升级成 problem。
- `tools/mfa_guard.py:528` `problems.append("MuMuManager 查不到实例 %s 的信息" % VM_INDEX)` ← **本次 ENV_DOWN 的唯一理由**
- `tools/mfa_guard.py:530` / `:532` 真正的「实例进程没在跑」/「安卓系统没起来」两条判据**依赖同一个 `info`** ⇒ `info=={}` 时它们根本没被求值，于是「工具崩」被读成「环境崩」。
- `tools/mfa_guard.py:13-14` 文档写死的恢复路：`1. MuMu 实例没起 -> MuMuManager control -v 1 launch`，实现在 `:420-421` ⇒ **今晚这条也用不了**。
- MFA 内部同一个依赖（不是我改的范围，只登记）：`agent/my_action.py:6142-6175` 从 Controller 上下文解析 `nx_main/MuMuManager.exe`，`:6212` 「进程退出码非零」、`:6217` 「stdout 为空」、`:6233` 「调用超时」、`:6518` 「未能定位有效的 MuMuManager.exe，安全终止任务」、`:6692`/`:6799` 「无法解析 MuMuManager 路径或 VM index」
  ⇒ 若 22:0x 拉起后 `[统一收宝石]` 连报上面任意一条，根因与本包同一件事。

## 候选改法（值守不动手，等芝麻点头）

1. `_run()` 返回 `(rc, stdout)`，`vm_info()` 在 **rc != 0 且 stdout 为空** 时打一行 `[guard] MuMuManager 退出码 0xc0000142，环境判据降级为 adb-only`，并把这条与「实例真不存在」**分成两个 problem 名**。依据：本次 ENV_DOWN 的成因是工具进程初始化失败，不是模拟器。
2. `mfa_guard` 的实例存活判据加一条**不依赖 MuMuManager 的兜底**：`tasklist` 命中 `MuMuNxDevice.exe` + `adb -s <port> shell echo` rc=0 + `pidof <game>` 非空 ⇒ 视为「实例活着」，只把 MuMuManager 失败记成 warning。依据：本次这三条全过，而 ENV_DOWN 照样报了。
3. `MGR` 路径多候选（`nx_main`、`nx_device\<ver>\shell`）并在都失败时打印候选清单。依据：`D:\Start-MaaHappyFish.ps1:86` 用的是 `D:\MuMuPlayer\nx_device\15.0\shell\MuMuNxDevice.exe`，说明这台机上 MuMu 是 15.0 家族，`nx_main/MuMuManager.exe`（文件 mtime **2026-09-22 23:08:52**）与它之间的依赖可能已经错位。
4. 系统侧（要芝麻查）：0xc0000142 且 WER 无记录，常见原因是 **desktop heap 耗尽 / 服务会话里起 GUI 子系统程序 / 该 exe 的依赖 DLL 版本不匹配**。同机其它进程（`ping.exe`、MFA、MuMu 全家桶）都能正常起 ⇒ 更像 MuMuManager 自身的依赖问题，不是整机资源问题。

## 值守侧结论（本档）

- 分类：**不是模拟器崩、不是整机崩、不是 Agent 静默挂死**；是「**队列空闲 7 小时 50 分**（14:00:41 海星喂食停摆）+ **游戏停在非鱼缸页（海星页，「选择喂食」弹窗未关）** + **值守环境检查的一条腿（MuMuManager）断了**」。
- 21:26:43 那一档脚本给的是 **HEALTHY**（`new=0 lines=376 since_last=0.2`）——心跳行把 50 分钟停摆阈值和 guard 的「异常标记+队列空闲」两条判据一起穿过去了；本档（21:53:31）同一个状态改判 ENV_DOWN，理由却是工具崩溃。**两次 verdict 都没说出真相**，这是判据盲区，收紧与否由芝麻定。
- 本包动作：日间档（实测本地=Shanghai=21:5x）⇒ **只记录不重启**，未点任何按钮、未改 pipeline/json、未动勾选。
- 22:00 后的恢复前置（写给自己下一档）：游戏不在主鱼缸页 ⇒ 先点左上「返回」逐层退回（⛔ 不是安卓 BACK，⛔ 主鱼缸禁按 BACK），**⛔ 不点「补充」「一键充满」「充能」「全部取出」**（救援型/「一键」类按默认付费），回缸后再走窗口通道点「开始任务」，并回读 `[src=UI][op=StartTask]` + `准备执行任务队列` 才算拉起成功。
