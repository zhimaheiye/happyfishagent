# 修复定位：21:53:55 的新故障签名被内置宽规则并进 patrol_gate_abort（值守覆盖缺口）

**一句话**：MFA 打出一条**三天日志里从未出现过**的巡检自杀文案
`[巡检] ERROR：从喂食弹窗启动时无法可靠判断当前海星，已安全停止。`
值守脚本却报 `new_issues=[]` —— 因为这条文案被 `tools/mfa_night_watch.py:72` 的**内置宽规则**接走，归进了已知条目 `patrol_gate_abort`。结果：不单独登记、不单独取证、台账里 `patrol_gate_abort` 的 19 次现在混着**三类不同根因**，芝麻从台账看不出「今天多了一种新死法」。

## 事实链（全部 2026-10-14 22:2x 实测，无一条推断）

| # | 观测 | 实测值 |
|---|---|---|
| 1 | 海星判定自杀行全天出现次数 | **1** 次 = `21:53:55.740 [src=Agent][op=Stdout]`，之前三天 0 次 |
| 2 | 值守状态.json（22:20:42） | `verdict=ENV_DOWN`、`new_issues=[]`、`known_hits=[{id: patrol_gate_abort, count: 3, lines: [185,583,584], sample: 那条海星行, total_in_ledger: 19}]` |
| 3 | 用 `已知问题.json` 全部 **32** 条 pattern 逐条正则试这条海星行 | **0 命中**（连 `patrol_gate_abort` 自己那条都不命中：`\[巡检(?:-[^\]]*)?\].*(?:ERROR：)?页面门禁未通过\|PatrolAbort` 要求「页面门禁未通过」字样） |
| 4 | 真正接住它的是哪条 | 内置 `RULES` 第 5 条（`mfa_night_watch.py:72`）：`\[巡检\].*(门禁未通过\|未识别\|安全停止)\|PatrolAbort` —— **「安全停止」三个字把它吞了** |
| 5 | 命中后为什么不产新异常 | `classify` 命中即 `break`（`:169`），`:232` 注释「★ 必须排在内置 RULES 前面」，`:239 eff_rules += list(RULES)`，`:254-270` 只有 `classify` 返回空才 `new_issues.append` |
| 6 | `sample` 为什么恰好是海星行 | `:264` 写的是 `"sample": h["line"]` = **命中行本身** ⇒ 反过来证明命中来自内置宽规则，而不是台账条目 |
| 7 | `count=3` 的构成 | 185 = 海星行；583+584 = `21:55:14.386 [src=Agent]` 与 `21:55:14.389 [src=Monitor]` —— **同一次「页面门禁未通过」的双写**（Agent/Monitor 成对打印）。⇒ `count` 不是事件数，一次事件算两行 |
| 8 | 同窗口另外两类被同一规则吞掉的行 | 今天另有 3 条 `[巡检] ERROR：未识别到已支持页面，已安全停止。`（04:40:34 / 04:46:16 / 04:49:25）也走 `安全停止` 分支，与门禁类同桶 |

## 代码定位

- `tools/mfa_night_watch.py:55-79` = `RULES` 规则表；**`:72` = `patrol_gate_abort` 宽规则**（三个不同根因共用一个桶：门禁未通过 / 未识别到已支持页面 / 海星弹窗判定失败）。
- `tools/mfa_night_watch.py:169 def classify(...)`、`:232` 顺序注释、`:239 eff_rules += list(RULES)`、`:254-270` new_issues / dups 分流、`:264 "sample": h["line"]`。
- `MFA夜间值守/已知问题.json` → `issues.patrol_gate_abort.pattern`（窄，只认领「页面门禁未通过」）、`issues.patrol_lucky_moment_popup_hang`（10-14 00:50 已收窄）、`issues.patrol_death_banner`（context）。
- MFA 侧文案出处：**未逐行核到源码行号**（只确认它是 `[src=Agent][op=Stdout]` 的 Agent 文案；对应节点名在 `debug/maafw.log`，GUI 日志里没有节点名）。要定到行得先 grep `agent/` 里那句「无法可靠判断当前海星」。

## 候选修法（**由芝麻定，值守不改脚本**）

1. 把 `:72` 拆成三条窄规则，分别 `页面门禁未通过` / `未识别到已支持页面` / `从喂食弹窗启动时无法可靠判断当前海星`，第三条先 `known=false` 走新异常路径（取证+打包），确认后再归档。
2. 或者保留一条规则，但在 `已知问题.json` 给 `patrol_gate_abort` 加 `sub_signatures` 分桶计数，台账里能看出「门禁 N 次 / 未识别 M 次 / 海星判定 K 次」。
3. 无论哪种，**先把 Agent/Monitor 成对双写去重**（否则 count 虚高约 2 倍，见事实链第 7 行）。
4. 改完用 `python tools/mfa_evidence_pack.py --list` + 跑一天 dry-run，比对分桶前后条数，再动 `STALL_MIN`（那是另一个芝麻未定的旋钮）。

## 值守侧结论（本周期定性）

- **本周期 verdict=ENV_DOWN 仍是工具假阴性**，根因与 21:53 那次同一条：`MuMuManager.exe` 全部子命令 rc=`0xc0000142`（STATUS_DLL_INIT_FAILED）、stdout/stderr 全空 → `tools/mumu_dev.py:40-45 _run()` 丢 rc → `tools/mfa_guard.py:528` 唯一 reason，`:530/:532` 真判据没评估。修复定位页已随 commit `236dc41` 推在上一包里。
- **环境实况（不重启的依据）**：22:20:08 三只海星复检完成 → 22:20:14 已确认返回鱼缸 3 → 22:20:16 `本轮多鱼缸巡检已完成…下次主巡检 22:20:46（约 30 秒后）` → 22:20:47 `间隔已到` → 22:20:52 缸1；22:10→22:20 共 140 行业务行、`任务失败`/`ERROR`/`StopTask` **0**。队列在跑，⛔ 没点任何按钮、没碰 MFA 窗口、没起进程。
- **缺口已登记**：今后 `new_issues=[]` **不能当「没有新故障」**读；凡是 `[巡检] ERROR：…已安全停止。` 家族都要人工比文案，本条海星判定签名按「新故障、未被登记」处理。
- 红线复扫（全天）：气泡 N>30 = 0、`好友摸宝` = 0、`未使用的体力` = 0、`开心宝` = 0、`一键` = 0、加好友类文案 = 0；22:00 档兜底未触发而配置实读为「开启」⇒ 矛盾原样上交，⛔ 不动勾选、不改间隔（眼下整夜跑的是 30 秒测试项）。
