# MFA 值守故障 · 2026-10-07 全日错误日志汇总

主题：10-07 全天 14 个 maafw 会话 + 主程序日志 + on_error 现场截图的错误筛选汇总。
全天自动化大部分时间正常运行；实质异常集中在 **15:55→17:31 会话尾段（17:26 模拟器截屏失败 ×79）** 与 **19:49→21:55 会话（get_display_id 失败 ×10）**，其余为启动/收尾琐碎错误与框架轮询噪音。

## 一、会话与错误总览（明细见 `maafw_err/summary.csv`）

bak 文件命名时间 = 会话被轮转（下一会话启动）的时刻，即该会话结束时刻。

| 会话（结束时刻） | 真实错误 | 轮询噪音 | 备注 |
|---|---|---|---|
| 10-06 22:24 → 05:07 | 0 | 6583 | 另有 6 条 10-06 时段启动/收尾琐碎错误，按日期过滤剔除 |
| 05:07 → 05:18 | 0 | 1381 | - |
| 05:18 → 09:50 | 0 | 8730 | - |
| 09:50 → 10:16 | 4 | 2180 | 启动/收尾琐碎（Tasker 创建/销毁时序） |
| 10:16 → 10:34 | 0 | 925 | - |
| 10:34 → 11:49 | 0 | 10088 | - |
| 11:49 → 13:52 | 0 | 17441 | - |
| 13:52 → 15:55 | 0 | 17626 | - |
| 15:55 → 17:31 | **79** | 12767 | **17:26 模拟器截屏失败窗口**，见下文 |
| 17:31 → 17:58 | 3 | 143 | 启动/收尾琐碎 |
| 17:58 → 19:49 | 0 | 15097 | - |
| 19:49 → 21:55 | **10** | 8925 | **get_display_id 失败 ×10**，见下文 |
| 21:55 → 23:57 | 4 | 9543 | 启动/收尾琐碎 |
| 23:58 → 次日 00:01（maafw.log） | 0 | 140 | 00:02 手动停止，正常收尾 |

- 「真实错误」= ERR/FTL 行中**剔除** `MaaTaskerGetRecognitionDetail failed to get_reco_result` 后的全部行，含错误行前 2 行 / 后 3 行上下文，按 2026-10-07 当日过滤。
- 「轮询噪音」= `MaaTasker.cpp L359 MaaTaskerGetRecognitionDetail failed to get_reco_result`：MaaFramework 在**每次识别事件**后 UI 查询识别详情未就绪时打出的一条 benign ERR，全天累计 **111,569 条**，不代表运行故障。每个会话保留前 30 条样本（`*.noise_sample.txt`）供确认。

## 二、真实错误明细

1. **17:26:22–17:26:35 截屏失败窗口（15:55 会话尾段，×79）** — `maafw_err/maafw.bak.2026.10.07-17.31.01.622.err.log`
   - `MuMuPlayerExtras::get_display_id` Failed to get display id `[display_id=-1]` ×16
   - `MuMuPlayerExtras::screencap` Failed to capture display `[ret=1]` ×16
   - `AdbControlUnitMgr::_screencap` failed to screencap ×16（re-screencap 重试 j=0→5 逐次递增仍失败）
   - 连带 `Tasker::task_id_to_runner_id` ×20、`Tasker::post_task` ×10、`ControllerAgent::check_stop` ×1
   - 形态：两条并发任务线程同时反复截屏失败约 13 秒后恢复，随后 17:31 用户重启会话。
2. **19:49→21:55 会话 get_display_id 失败 ×10** — `maafw_err/maafw.bak.2026.10.07-21.55.28.778.err.log`
3. **启动/收尾琐碎（各 3–4 条）**：10:16 / 17:58 / 23:57 会话的 `MaaTaskerGetResource / MaaTaskerGetController handle is null`、`MaaControllerCachedImage image is empty`、`UnitBase::startup_and_read_pipe`，均为 Tasker/Controller 创建销毁时序的正常伴生错误。

## 三、主程序日志（`logs/`）

- `log-20261007.log`：全天主程序日志，原样收录。无 ERR/FTL；仅 3 条 WRN「跨平台数据解密失败：参数错误」，出现时刻 09:51 / 17:31 / 21:55 均为会话启动时，与重启动作对应。
- `log-20261008.log`：10-07 夜班收尾（00:00–00:03），00:02:12 手动停止任务（「已放弃本次任务」），供还原夜班结束过程。

## 四、on_error 现场截图（128 张 → 采样 17 张 + 完整清单）

全天 `debug/on_error/` 共 128 张（91.2MB），完整清单（文件名 / 小时 / 场景 / 是否入包）见 `on_error/完整清单.csv`。

| 场景 | 张数 | 入包策略 |
|---|---|---|
| PatrolCollectTank1/2/3ImageWindow（巡检复查残留产物识别窗） | 113 | 同一识别场景全天高频复现（每轮巡检三缸各 1 张、约每 18–19 分钟一轮），按每缸保留首末样本共 6 张 |
| PatrolSweepTank2AfterBubble（气泡后扫底） | 4 | 全部保留（05:08 ×2、13:58 ×2） |
| PatrolSweepTank1AfterBubble | 2 | 全部保留（15:47、23:59） |
| GreenWildClaimReward（绿野寻仙踪领奖） | 1 | 保留（12:04，奖励页顶部出现「闪电水」提示气泡） |
| SeaOtterRecommendedBridge / SeaOtterNavigationFailed（海獭导航） | 2 | 保留（17:54，17:31 会话内海獭导航失败） |
| HangupClickReturnPatrol（挂机点击返回巡检） | 1 | 保留（23:32） |
| PatrolAbortUnknownPage（巡检未知页面中止） | 1 | 保留（23:48） |

如需全量 128 张原图，可另行打包提供。

## 五、目录结构

```
logs/        主程序日志（原样）
maafw_err/   各会话 ERR/FTL 筛选结果（*.err.log，仅 5 个会话非空）
             + 轮询噪音样本（*.noise_sample.txt，每会话前 30 条）
             + summary.csv（14 会话统计总表）
on_error/    错误现场截图（17 张采样）+ 完整清单.csv（128 条）
```
